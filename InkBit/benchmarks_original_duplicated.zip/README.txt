PIECES dataset contains 2046 items. MIXTURE contains 827 items. LOCKS contains 300 items.
We first sort them according to bounding box sizes and the pack. For details please see. https://inkbit3d.com/packing/
Parts in LOCKS and PIECES dataset are designed by Inkbit. MIXTURE credit @ Qingnan Zhou and Alec Jacobson. 2016. Thingi10k